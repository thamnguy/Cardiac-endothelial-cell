groupNumber = {
    [43 41 37], ... % naive P28
    [42 40 39], ... % naive P56
    [34 30 27 26 19 17 10], ... %AR + MI
    [7 6 3 2 5], ... %AR + MI
    [1 4 9 13 18 14 21], ... %AR + MI
    [35 29 24 22], ... %AR + MI
    [12 11 15 20 16 23 8 ], ... %AR + MI
    [34 32], ...%AR + MI
    [25 28 31 36 38 33]}; %MI-only

newIDX = zeros( length(clusterIdentifiers), 1 );
for i = 1 : length(groupNumber)
    newIDX (ismember(clusterIdentifiers', groupNumber{i})) = i;
end

figure, gscatter(coordinate(:, 1), coordinate(:, 2), newIDX);

%%
groupNumber = {
    [43 41 37 42 40 39], ... % naive P56
    [34 30 27 26 19 17 10 7 6 3 2 5 1 4 9 13 18 14 21 35 29 24 22 12 11 15 20 16 23 8 34 32], ...%AR + MI
    [25 28 31 36 38 33]}; %MI-only

newIDX = zeros( length(clusterIdentifiers), 1 );
for i = 1 : length(groupNumber)
    newIDX (ismember(clusterIdentifiers', groupNumber{i})) = i;
end

figure, gscatter(coordinate(:, 1), coordinate(:, 2), newIDX);
